// Copyright 2025 β ORI Inc. All Rights Reserved. Awase Khirni Syed
//

// Initialize logger
const logger = {
  logs: [],
  maxSize: 5000,

  addLog: function (type, data) {
    this.logs.push({
      type,
      timestamp: Date.now(),
      data,
    });

    if (this.logs.length > this.maxSize) {
      this.logs.shift();
    }
  },

  getLogs: function () {
    return this.logs;
  },
};

// Message handler
browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.type) {
    case "GET_LOGS":
      sendResponse(logger.getLogs());
      break;

    case "EXPORT_LOGS":
      exportLogs().then((success) => {
        sendResponse({ success });
      });
      return true;
  }
});

// Network monitoring
browser.webRequest.onCompleted.addListener(
  (details) => {
    logger.addLog("NETWORK", {
      url: details.url,
      method: details.method,
      status: details.statusCode,
    });
  },
  { urls: ["<all_urls>"] },
);

// Export function
async function exportLogs() {
  try {
    const blob = new Blob([JSON.stringify(logger.getLogs(), null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);

    await browser.downloads.download({
      url: url,
      filename: `network_logs_${Date.now()}.json`,
    });

    URL.revokeObjectURL(url);
    return true;
  } catch (error) {
    console.error("Export failed:", error);
    return false;
  }
}
