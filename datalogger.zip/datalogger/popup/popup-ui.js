export default class UI {
    constructor() {
        this.elements = {
            toggle: document.getElementById('toggle-logging'),
            logCount: document.getElementById('log-count'),
            lastExport: document.getElementById('last-export'),
            exportBtn: document.getElementById('export-now'),
            statusMsg: document.getElementById('status-message')
        };
    }

    async init() {
        await this.loadInitialState();
        this.setupEventListeners();
    }

    async loadInitialState() {
        try {
            const response = await chrome.runtime.sendMessage({type: 'GET_STATS'});

            this.elements.toggle.checked = response.isActive;
            this.elements.logCount.textContent = response.logCount;
            this.elements.lastExport.textContent = response.lastExport || "Never";
        } catch (error) {
            this.showError("Failed to load initial state");
        }
    }

    setupEventListeners() {
        this.elements.toggle.addEventListener('change', async () => {
            const isActive = this.elements.toggle.checked;
            const response = await chrome.runtime.sendMessage({
                type: 'TOGGLE_LOGGING',
                active: isActive
            });

            if (!response.success) {
                this.elements.toggle.checked = !isActive;
                this.showError(response.error || "Failed to toggle logging");
            }
        });

        this.elements.exportBtn.addEventListener('click', async () => {
            this.showStatus("Exporting logs...");

            const response = await chrome.runtime.sendMessage({type: 'EXPORT_LOGS'});

            if (response.success) {
                this.elements.lastExport.textContent = new Date(response.lastExport).toLocaleString();
                this.showStatus("Export completed successfully", true);
            } else {
                this.showError(response.error || "Export failed");
            }
        });
    }

    showStatus(message, isSuccess = false) {
        const status = this.elements.statusMsg;
        status.textContent = message;
        status.className = isSuccess ? 'success' : 'info';
        setTimeout(() => status.textContent = '', 3000);
    }

    showError(message) {
        const status = this.elements.statusMsg;
        status.textContent = message;
        status.className = 'error';
        setTimeout(() => status.textContent = '', 5000);
    }
}
