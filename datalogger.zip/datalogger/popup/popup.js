document.addEventListener('DOMContentLoaded', () => {
    const logCount = document.getElementById('log-count');
    const exportBtn = document.getElementById('export-btn');
    const viewBtn = document.getElementById('view-btn');
    const clearBtn = document.getElementById('clear-btn');
    const statusEl = document.getElementById('status');

    // Update log count
    updateLogCount();

    // Button handlers
    exportBtn.addEventListener('click', exportLogs);
    viewBtn.addEventListener('click', viewLogs);
    clearBtn.addEventListener('click', clearLogs);

    async function updateLogCount() {
        const logs = await browser.runtime.sendMessage({type: 'GET_LOGS'});
        logCount.textContent = logs.length;
    }

    async function exportLogs() {
        statusEl.textContent = "Exporting...";
        const {success} = await browser.runtime.sendMessage({type: 'EXPORT_LOGS'});
        statusEl.textContent = success ? "Export complete!" : "Export failed";
        setTimeout(() => statusEl.textContent = "", 3000);
    }

    function viewLogs() {
        browser.tabs.create({
            url: browser.runtime.getURL("logs/logs.html")
        });
    }

    async function clearLogs() {
        await browser.runtime.sendMessage({type: 'CLEAR_LOGS'});
        statusEl.textContent = "Logs cleared";
        updateLogCount();
        setTimeout(() => statusEl.textContent = "", 2000);
    }
});
