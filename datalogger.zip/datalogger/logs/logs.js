// Copyright 2025 β ORI Inc. All Rights Reserved. Awase Khirni Syed
//
document.addEventListener("DOMContentLoaded", async () => {
  const logContainer = document.getElementById("log-container");

  try {
    // Get logs from background script
    const logs = await browser.runtime.sendMessage({ type: "GET_LOGS" });

    if (!logs || logs.length === 0) {
      logContainer.innerHTML = '<p class="empty">No logs available</p>';
      return;
    }

    // Display logs
    logs.forEach((log) => {
      const logElement = document.createElement("div");
      logElement.className = "log-entry";
      logElement.innerHTML = `
        <div class="log-header">
          <span class="log-type ${log.type}">${log.type}</span>
          <span class="log-timestamp">
            ${new Date(log.timestamp).toLocaleString()}
          </span>
        </div>
        <div class="log-url">URL: ${log.data.url}</div>
        <pre class="log-data">${JSON.stringify(log.data, null, 2)}</pre>
      `;
      logContainer.appendChild(logElement);
    });
  } catch (error) {
    logContainer.innerHTML = `
      <p class="error">
        Failed to load logs: ${error.message}
      </p>
    `;
  }
});
